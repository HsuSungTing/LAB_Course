//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//    (C) Copyright System Integration and Silicon Implementation Laboratory
//    All Right Reserved
//		Date		: 2025/10
//		Version		: v1.0
//   	File Name   : WinRate.v
//   	Module Name : WinRate
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//############################################################################

`include "Poker.v"

module WinRate (
    // Input signals
    clk,
	rst_n,
	in_valid,
    in_hole_num,
    in_hole_suit,
    in_pub_num,
    in_pub_suit,
    out_valid,
    out_win_rate
);
// ===============================================================
// Input & Output
// ===============================================================
input clk;
input rst_n;
input in_valid;
input [71:0] in_hole_num;
input [35:0] in_hole_suit;
input [11:0] in_pub_num;
input [6:0] in_pub_suit;

output reg out_valid;
output reg [62:0] out_win_rate;
// ===============================================================
// Reg & Wire
// ===============================================================
wire [8:0] out_winner;
reg [1:0] cur_state, next_state;
reg [5:0] turn_card, river_card;
reg [5:0] next_turn_card, next_river_card;


wire [3:0] turn_num, river_num;
wire [1:0] turn_suit, river_suit;

wire [5:0] turn_card_1, river_card_1;
wire [3:0] river_num_1;
wire [1:0] river_suit_1;

wire Poker_out_available;

reg card_available[14:2][3:0];
reg [71:0] in_hole_num_reg;
reg [35:0] in_hole_suit_reg;
reg [11:0] in_pub_num_reg;
reg [5:0] in_pub_suit_reg;

reg [3:0] card_num[17:0];
reg [1:0] card_suit[17:0];
reg [3:0] pub_card_num[2:0];
reg [1:0] pub_card_suit[2:0];

wire [3:0] winner_count;
reg [8:0] player_result [8:0];
reg [3:0] player_chop_9 [8:0];
reg [1:0] player_chop_4 [8:0];
reg [1:0] player_chop_3 [8:0];
reg  player_chop_2 [8:0];

reg [8:0] next_player_result [8:0];
reg [3:0] next_player_chop_9 [8:0];
reg [1:0] next_player_chop_4 [8:0];
reg [1:0] next_player_chop_3 [8:0];
reg  next_player_chop_2 [8:0];

reg [9:0] counter;
//reg [6:0] remainder [8:0];
reg [10:0] remainder_1 [8:0];
reg [14:0] remainder_2 [8:0];
reg [6:0] player_win_rate [8:0];

parameter S_IDLE = 'd0;
parameter S_SETTING = 'd1;
parameter S_DEAL = 'd2;
parameter S_OUTPUT = 'd3;

genvar i, j;
integer k, l;
// ===============================================================
// Design
// ===============================================================

Poker #(.IP_WIDTH(9)) I_Poker_IP (
    .IN_HOLE_CARD_NUM(in_hole_num_reg),
    .IN_HOLE_CARD_SUIT(in_hole_suit_reg),
    .IN_PUB_CARD_NUM({in_pub_num_reg, turn_num, river_num}),
    .IN_PUB_CARD_SUIT({in_pub_suit_reg, turn_suit, river_suit}),
    .OUT_WINNER(out_winner)
);

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        cur_state <= S_IDLE;
    end
    else begin
        cur_state <= next_state;
    end
end

always @(*) begin
    case (cur_state)
        S_IDLE: begin
            if(in_valid) next_state = S_SETTING;
            else next_state = S_IDLE;
        end
        S_SETTING: begin
            next_state = S_DEAL;
        end
        S_DEAL: begin
            if(next_turn_card == 51) next_state = S_OUTPUT;
            else next_state = S_DEAL;
        end
        S_OUTPUT: begin
            next_state = S_IDLE;
        end
        default: next_state = cur_state;
    endcase
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        in_hole_num_reg <= 0;
        in_hole_suit_reg <= 0;
        in_pub_num_reg <= 0;
        in_pub_suit_reg <= 0;
    end
    else if(in_valid)begin
        in_hole_num_reg <= in_hole_num;
        in_hole_suit_reg <= in_hole_suit;
        in_pub_num_reg <= in_pub_num;
        in_pub_suit_reg <= in_pub_suit;
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        for(k=2; k<15; k=k+1)begin
            for(l=0; l<4; l=l+1)begin
                card_available[k][l] <= 0;
            end
        end
    end
    else if(cur_state == S_SETTING)begin
        for(k=2; k<15; k=k+1)begin
            for(l=0; l<4; l=l+1)begin
                card_available[k][l] <= 0;
            end
        end
        card_available[card_num[0]][card_suit[0]]   <= 1;
        card_available[card_num[1]][card_suit[1]]   <= 1;
        card_available[card_num[2]][card_suit[2]]   <= 1;
        card_available[card_num[3]][card_suit[3]]   <= 1;
        card_available[card_num[4]][card_suit[4]]   <= 1;
        card_available[card_num[5]][card_suit[5]]   <= 1;
        card_available[card_num[6]][card_suit[6]]   <= 1;
        card_available[card_num[7]][card_suit[7]]   <= 1;
        card_available[card_num[8]][card_suit[8]]   <= 1;
        card_available[card_num[9]][card_suit[9]]   <= 1;
        card_available[card_num[10]][card_suit[10]] <= 1;
        card_available[card_num[11]][card_suit[11]] <= 1;
        card_available[card_num[12]][card_suit[12]] <= 1;
        card_available[card_num[13]][card_suit[13]] <= 1;
        card_available[card_num[14]][card_suit[14]] <= 1;
        card_available[card_num[15]][card_suit[15]] <= 1;
        card_available[card_num[16]][card_suit[16]] <= 1;
        card_available[card_num[17]][card_suit[17]] <= 1;
        card_available[pub_card_num[0]][pub_card_suit[0]] <= 1;
        card_available[pub_card_num[1]][pub_card_suit[1]] <= 1;
        card_available[pub_card_num[2]][pub_card_suit[2]] <= 1;
    end
end

always @(*) begin
    card_num[0]  = in_hole_num_reg[3:0];
    card_num[1]  = in_hole_num_reg[7:4];
    card_num[2]  = in_hole_num_reg[11:8];
    card_num[3]  = in_hole_num_reg[15:12];
    card_num[4]  = in_hole_num_reg[19:16];
    card_num[5]  = in_hole_num_reg[23:20];
    card_num[6]  = in_hole_num_reg[27:24];
    card_num[7]  = in_hole_num_reg[31:28];
    card_num[8]  = in_hole_num_reg[35:32];
    card_num[9]  = in_hole_num_reg[39:36];
    card_num[10] = in_hole_num_reg[43:40];
    card_num[11] = in_hole_num_reg[47:44];
    card_num[12] = in_hole_num_reg[51:48];
    card_num[13] = in_hole_num_reg[55:52];
    card_num[14] = in_hole_num_reg[59:56];
    card_num[15] = in_hole_num_reg[63:60];
    card_num[16] = in_hole_num_reg[67:64];
    card_num[17] = in_hole_num_reg[71:68];

    card_suit[0]  = in_hole_suit_reg[1:0];
    card_suit[1]  = in_hole_suit_reg[3:2];
    card_suit[2]  = in_hole_suit_reg[5:4];
    card_suit[3]  = in_hole_suit_reg[7:6];
    card_suit[4]  = in_hole_suit_reg[9:8];
    card_suit[5]  = in_hole_suit_reg[11:10];
    card_suit[6]  = in_hole_suit_reg[13:12];
    card_suit[7]  = in_hole_suit_reg[15:14];
    card_suit[8]  = in_hole_suit_reg[17:16];
    card_suit[9]  = in_hole_suit_reg[19:18];
    card_suit[10] = in_hole_suit_reg[21:20];
    card_suit[11] = in_hole_suit_reg[23:22];
    card_suit[12] = in_hole_suit_reg[25:24];
    card_suit[13] = in_hole_suit_reg[27:26];
    card_suit[14] = in_hole_suit_reg[29:28];
    card_suit[15] = in_hole_suit_reg[31:30];
    card_suit[16] = in_hole_suit_reg[33:32];
    card_suit[17] = in_hole_suit_reg[35:34];

    pub_card_num[0]  = in_pub_num_reg[3:0];
    pub_card_num[1]  = in_pub_num_reg[7:4];
    pub_card_num[2]  = in_pub_num_reg[11:8];
    
    pub_card_suit[0]  = in_pub_suit_reg[1:0];
    pub_card_suit[1]  = in_pub_suit_reg[3:2];
    pub_card_suit[2]  = in_pub_suit_reg[5:4];
end

assign turn_suit = turn_card[1:0];
assign turn_num = turn_card[5:2] + 2;
assign river_suit = river_card[1:0];
assign river_num = river_card[5:2] + 2;

assign river_card_1 = river_card + 1;
assign river_suit_1 = river_card_1[1:0];
assign river_num_1 = river_card_1[5:2] + 2;

assign Poker_out_available = !card_available[turn_num][turn_suit] && !card_available[river_num][river_suit] && turn_card<51;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        turn_card <= 0;
        river_card <= 1;
    end
    else begin
        turn_card <= next_turn_card;
        river_card <= next_river_card;
    end
end

always @(*) begin
    if(cur_state == S_DEAL) begin
        if(card_available[turn_num][turn_suit]) begin
            next_turn_card = turn_card + 1;
            next_river_card = turn_card + 2;
        end 
        else if (river_card==51) begin
            next_turn_card = turn_card + 1;
            next_river_card = turn_card + 2;
        end 
        else if(card_available[river_num_1][river_suit_1] && river_card != 50) begin
            next_turn_card = turn_card ;
            next_river_card = river_card + 2;
        end
        else begin
            next_turn_card = turn_card ;
            next_river_card = river_card_1;
        end
    end
    else begin
        next_turn_card = 0;
        next_river_card = 1;
    end
end

assign winner_count = ((out_winner[0] + out_winner[1]) + (out_winner[2] + out_winner[3])) + ((out_winner[4] + out_winner[5]) + (out_winner[6] + out_winner[7]) + out_winner[8]);

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        for(k=0; k<9; k=k+1)begin
            player_result[k] <= 0;
            player_chop_2[k] <= 0;
            player_chop_3[k] <= 0;
            player_chop_4[k] <= 0;
            player_chop_9[k] <= 0;
        end
    end
    else begin
        for(k=0; k<9; k=k+1)begin
            player_result[k] <= next_player_result[k];
            player_chop_2[k] <= next_player_chop_2[k];
            player_chop_3[k] <= next_player_chop_3[k];
            player_chop_4[k] <= next_player_chop_4[k];
            player_chop_9[k] <= next_player_chop_9[k];
        end
    end
end

always @(*) begin
    for(k=0; k<9; k=k+1)begin
        next_player_result[k] = player_result[k];
        next_player_chop_2[k] = player_chop_2[k];
        next_player_chop_3[k] = player_chop_3[k];
        next_player_chop_4[k] = player_chop_4[k];
        next_player_chop_9[k] = player_chop_9[k];
    end
    if(cur_state == S_DEAL && Poker_out_available) begin
        case (winner_count)
            'd1: begin
                for(k=0; k<9; k=k+1)begin
                    if(out_winner[k])  next_player_result[k] = player_result[k] + 1;
                end
            end
            'd2: begin
                for(k=0; k<9; k=k+1)begin
                    if(out_winner[k]) begin
                        if(player_chop_2[k]) begin
                            next_player_result[k] = player_result[k] + 1;
                            next_player_chop_2[k] = 0;
                        end
                        else next_player_chop_2[k] = 1;
                    end
                end
            end
            'd3: begin
                for(k=0; k<9; k=k+1)begin
                    if(out_winner[k]) begin
                        if(player_chop_3[k]==2) begin
                            next_player_result[k] = player_result[k] + 1;
                            next_player_chop_3[k] = 0;
                        end
                        else next_player_chop_3[k] = player_chop_3[k] + 1;
                    end
                end
            end
            'd4: begin
                for(k=0; k<9; k=k+1)begin
                    if(out_winner[k]) begin
                        if(player_chop_4[k]==3) begin
                            next_player_result[k] = player_result[k] + 1;
                            next_player_chop_4[k] = 0;
                        end
                        else next_player_chop_4[k] = player_chop_4[k] + 1;
                    end
                end
            end 
            'd9: begin
                for(k=0; k<9; k=k+1)begin
                    if(out_winner[k]) begin
                        if(player_chop_9[k]==8) begin
                            next_player_result[k] = player_result[k] + 1;
                            next_player_chop_9[k] = 0;
                        end
                        else next_player_chop_9[k] = player_chop_9[k] + 1;
                    end
                end
            end
        endcase    
    end
    else if(cur_state == S_SETTING)begin
        for(k=0; k<9; k=k+1)begin
            next_player_result[k] = 0;
            next_player_chop_2[k] = 0;
            next_player_chop_3[k] = 0;
            next_player_chop_4[k] = 0;
            next_player_chop_9[k] = 0;
        end
    end
end


always @(*) begin
    for(k=0; k<9; k=k+1)begin
        //remainder[k] = (18*player_chop_2[k] + 12*player_chop_3[k]) + (9*player_chop_4[k] + 4*player_chop_9[k]);
        remainder_1[k] = ({player_result[k], 2'b00} + {player_chop_2[k], 1'b0} + player_chop_4[k]);
        remainder_2[k] = (60*player_chop_3[k] + 20*player_chop_9[k]);
        player_win_rate[k] = (remainder_1[k] * 5 + remainder_2[k]/9) / 93;
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        out_valid <= 0;
        out_win_rate <= 0;
    end
    else begin
        if(cur_state == S_OUTPUT) begin
            out_valid <= 1;
            out_win_rate <= {player_win_rate[8], player_win_rate[7], player_win_rate[6], player_win_rate[5], player_win_rate[4], player_win_rate[3], player_win_rate[2], player_win_rate[1], player_win_rate[0]}; 
        end
        else begin
            out_valid <= 0;
            out_win_rate <= 0;
        end
    end
end


endmodule