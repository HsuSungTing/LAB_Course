"""
H.264 Lite Pre-Entropy Encoder Test Pattern Generator
完整實現編碼循環（包含重建）
所有圖像使用隨機像素
"""

import numpy as np
import random

# ============================================================================
# H.264 編碼參數
# ============================================================================

C = np.array([
    [ 1,  1,  1,  1],
    [ 1,  1, -1, -1],
    [ 1, -1, -1,  1],
    [ 1, -1,  1, -1]
], dtype=np.int32)

# MF table
MF_TABLE = {
    0:  {'a': 13107, 'b': 5243, 'c': 8066},
    1:  {'a': 11916, 'b': 4660, 'c': 7490},
    2:  {'a': 10082, 'b': 4194, 'c': 6554},
    3:  {'a': 9362,  'b': 3647, 'c': 5825},
    4:  {'a': 8192,  'b': 3355, 'c': 5243},
    5:  {'a': 7282,  'b': 2893, 'c': 4559},
    6:  {'a': 13107, 'b': 5243, 'c': 8066},
    7:  {'a': 11916, 'b': 4660, 'c': 7490},
    8:  {'a': 10082, 'b': 4194, 'c': 6554},
    9:  {'a': 9362,  'b': 3647, 'c': 5825},
    10: {'a': 8192,  'b': 3355, 'c': 5243},
    11: {'a': 7282,  'b': 2893, 'c': 4559},
    12: {'a': 13107, 'b': 5243, 'c': 8066},
    13: {'a': 11916, 'b': 4660, 'c': 7490},
    14: {'a': 10082, 'b': 4194, 'c': 6554},
    15: {'a': 9362,  'b': 3647, 'c': 5825},
    16: {'a': 8192,  'b': 3355, 'c': 5243},
    17: {'a': 7282,  'b': 2893, 'c': 4559},
    18: {'a': 13107, 'b': 5243, 'c': 8066},
    19: {'a': 11916, 'b': 4660, 'c': 7490},
    20: {'a': 10082, 'b': 4194, 'c': 6554},
    21: {'a': 9362,  'b': 3647, 'c': 5825},
    22: {'a': 8192,  'b': 3355, 'c': 5243},
    23: {'a': 7282,  'b': 2893, 'c': 4559},
    24: {'a': 13107, 'b': 5243, 'c': 8066},
    25: {'a': 11916, 'b': 4660, 'c': 7490},
    26: {'a': 10082, 'b': 4194, 'c': 6554},
    27: {'a': 9362,  'b': 3647, 'c': 5825},
    28: {'a': 8192,  'b': 3355, 'c': 5243},
    29: {'a': 7282,  'b': 2893, 'c': 4559},
}

# V table
V_TABLE = {
    0:  {'a': 10, 'b': 16, 'c': 13},
    1:  {'a': 11, 'b': 18, 'c': 14},
    2:  {'a': 13, 'b': 20, 'c': 16},
    3:  {'a': 14, 'b': 23, 'c': 18},
    4:  {'a': 16, 'b': 25, 'c': 20},
    5:  {'a': 18, 'b': 29, 'c': 23},
    6:  {'a': 10, 'b': 16, 'c': 13},
    7:  {'a': 11, 'b': 18, 'c': 14},
    8:  {'a': 13, 'b': 20, 'c': 16},
    9:  {'a': 14, 'b': 23, 'c': 18},
    10: {'a': 16, 'b': 25, 'c': 20},
    11: {'a': 18, 'b': 29, 'c': 23},
    12: {'a': 10, 'b': 16, 'c': 13},
    13: {'a': 11, 'b': 18, 'c': 14},
    14: {'a': 13, 'b': 20, 'c': 16},
    15: {'a': 14, 'b': 23, 'c': 18},
    16: {'a': 16, 'b': 25, 'c': 20},
    17: {'a': 18, 'b': 29, 'c': 23},
    18: {'a': 10, 'b': 16, 'c': 13},
    19: {'a': 11, 'b': 18, 'c': 14},
    20: {'a': 13, 'b': 20, 'c': 16},
    21: {'a': 14, 'b': 23, 'c': 18},
    22: {'a': 16, 'b': 25, 'c': 20},
    23: {'a': 18, 'b': 29, 'c': 23},
    24: {'a': 10, 'b': 16, 'c': 13},
    25: {'a': 11, 'b': 18, 'c': 14},
    26: {'a': 13, 'b': 20, 'c': 16},
    27: {'a': 14, 'b': 23, 'c': 18},
    28: {'a': 16, 'b': 25, 'c': 20},
    29: {'a': 18, 'b': 29, 'c': 23},
}

def get_qbits(qp):
    return 15 + (qp // 6)

def get_f_offset(qp):
    if qp < 6:
        return 10922
    elif qp < 12:
        return 21845
    elif qp < 18:
        return 43690
    elif qp < 24:
        return 87381
    else:
        return 174762

def get_qp_div6(qp):
    return qp // 6

# ============================================================================
# 反量化和反轉換
# ============================================================================

def get_V_matrix(qp):
    params = V_TABLE[qp]
    a, b, c = params['a'], params['b'], params['c']
    V = np.array([
        [a, c, a, c],
        [c, b, c, b],
        [a, c, a, c],
        [c, b, c, b]
    ], dtype=np.int32)
    return V

def dequantize(Z, qp):
    qp_div6 = get_qp_div6(qp)
    V = get_V_matrix(qp)
    
    W_prime = np.zeros_like(Z, dtype=np.int32)
    
    for i in range(4):
        for j in range(4):
            W_prime[i, j] = (Z[i, j] * V[i, j]) << qp_div6
    
    return W_prime

def inverse_transform(W_prime):
    temp = C.T @ W_prime
    residual_prime = (temp @ C) >> 6
    return residual_prime

def clip(value, min_val=0, max_val=255):
    return np.clip(value, min_val, max_val)

# ============================================================================
# 編碼函數
# ============================================================================

def get_MF_matrix(qp):
    params = MF_TABLE[qp]
    a, b, c = params['a'], params['b'], params['c']
    MF = np.array([
        [a, c, a, c],
        [c, b, c, b],
        [a, c, a, c],
        [c, b, c, b]
    ], dtype=np.int32)
    return MF

def intra_predict_dc(top, left, top_avail, left_avail, block_size):
    if block_size == 4:
        shift_both, shift_one = 3, 2
    else:
        shift_both, shift_one = 5, 4
    
    if top_avail and left_avail:
        dc = (np.sum(top) + np.sum(left)) >> shift_both
    elif top_avail:
        dc = np.sum(top) >> shift_one
    elif left_avail:
        dc = np.sum(left) >> shift_one
    else:
        dc = 128
    
    return np.full((block_size, block_size), dc, dtype=np.uint8)

def intra_predict_horizontal(left, block_size):
    return np.repeat(left.reshape(-1, 1), block_size, axis=1).astype(np.uint8)

def intra_predict_vertical(top, block_size):
    return np.repeat(top.reshape(1, -1), block_size, axis=0).astype(np.uint8)

def calculate_sad(block, pred):
    return int(np.sum(np.abs(block.astype(np.int16) - pred.astype(np.int16))))

def select_intra4x4_mode(block, top, left, top_avail, left_avail):
    modes = {}
    
    pred_dc = intra_predict_dc(top, left, top_avail, left_avail, 4)
    sad_dc = calculate_sad(block, pred_dc)
    modes['DC'] = {'pred': pred_dc, 'sad': sad_dc}
    
    if left_avail:
        pred_h = intra_predict_horizontal(left, 4)
        sad_h = calculate_sad(block, pred_h)
        modes['H'] = {'pred': pred_h, 'sad': sad_h}
    
    if top_avail:
        pred_v = intra_predict_vertical(top, 4)
        sad_v = calculate_sad(block, pred_v)
        modes['V'] = {'pred': pred_v, 'sad': sad_v}
    
    best_mode = 'DC'
    min_sad = modes['DC']['sad']
    
    if left_avail and modes['H']['sad'] < min_sad:
        best_mode = 'H'
        min_sad = modes['H']['sad']
    
    if top_avail and modes['V']['sad'] < min_sad:
        best_mode = 'V'
    
    return modes[best_mode]['pred'], best_mode

def forward_transform(residual):
    T = C @ residual
    W = T @ C.T
    return W

def quantize(W, qp):
    qbits = get_qbits(qp)
    f = get_f_offset(qp)
    MF = get_MF_matrix(qp)
    
    Z = np.zeros_like(W, dtype=np.int32)
    
    for i in range(4):
        for j in range(4):
            w_val = W[i, j]
            sign = 1 if w_val >= 0 else -1
            abs_w = abs(int(w_val))
            
            mult = abs_w * int(MF[i, j])
            add_f = mult + f
            mag = add_f >> qbits
            
            Z[i, j] = sign * mag
    
    return Z

def encode_4x4_block(block, top, left, top_avail, left_avail, qp):
    # 1. Prediction
    pred, mode = select_intra4x4_mode(block, top, left, top_avail, left_avail)
    
    # 2. Residual
    residual = block.astype(np.int16) - pred.astype(np.int16)
    
    # 3. Forward Transform
    W = forward_transform(residual)
    
    # 4. Quantization (輸出)
    Z = quantize(W, qp)
    
    # 5. Dequantization
    W_prime = dequantize(Z, qp)
    
    # 6. Inverse Transform
    residual_prime = inverse_transform(W_prime)
    
    # 7. Reconstruction
    recon_raw = pred.astype(np.int16) + residual_prime
    recon = clip(recon_raw, 0, 255).astype(np.uint8)
    
    return Z, recon

def encode_macroblock_intra4x4(mb_pixels, recon_buffer, top_line, left_line, mb_org_x, mb_org_y, qp):
    Z_coeffs = []
    
    for br in range(4):
        for bc in range(4):
            by = br * 4
            bx = bc * 4
            
            block = mb_pixels[by:by+4, bx:bx+4]
            
            top_avail = (br != 0) or (mb_org_y != 0)
            left_avail = (bc != 0) or (mb_org_x != 0)
            
            if br != 0:
                top = recon_buffer[mb_org_y + by - 1, mb_org_x + bx:mb_org_x + bx + 4]
            elif mb_org_y != 0:
                top = top_line[mb_org_x + bx:mb_org_x + bx + 4]
            else:
                top = np.zeros(4, dtype=np.uint8)
            
            if bc != 0:
                left = recon_buffer[mb_org_y + by:mb_org_y + by + 4, mb_org_x + bx - 1]
            elif mb_org_x != 0:
                left = left_line[mb_org_y + by:mb_org_y + by + 4]
            else:
                left = np.zeros(4, dtype=np.uint8)
            
            Z, recon = encode_4x4_block(block, top, left, top_avail, left_avail, qp)
            
            recon_buffer[mb_org_y + by:mb_org_y + by + 4, 
                        mb_org_x + bx:mb_org_x + bx + 4] = recon
            
            for i in range(4):
                for j in range(4):
                    Z_coeffs.append(int(Z[i, j]))
    
    return Z_coeffs

def encode_macroblock_intra16x16(mb_pixels, recon_buffer, top_line, left_line, mb_org_x, mb_org_y, qp):
    top_avail = (mb_org_y != 0)
    left_avail = (mb_org_x != 0)
    
    if top_avail:
        top_16 = top_line[mb_org_x:mb_org_x+16]
    else:
        top_16 = np.zeros(16, dtype=np.uint8)
    
    if left_avail:
        left_16 = left_line[mb_org_y:mb_org_y+16]
    else:
        left_16 = np.zeros(16, dtype=np.uint8)
    
    if top_avail and left_avail:
        dc16 = (np.sum(top_16) + np.sum(left_16)) >> 5
    elif top_avail:
        dc16 = np.sum(top_16) >> 4
    elif left_avail:
        dc16 = np.sum(left_16) >> 4
    else:
        dc16 = 128
    
    sad_dc = calculate_sad(mb_pixels, np.full((16, 16), dc16, dtype=np.uint8))
    
    sad_h = float('inf')
    if left_avail:
        pred_h = intra_predict_horizontal(left_16, 16)
        sad_h = calculate_sad(mb_pixels, pred_h)
    
    sad_v = float('inf')
    if top_avail:
        pred_v = intra_predict_vertical(top_16, 16)
        sad_v = calculate_sad(mb_pixels, pred_v)
    
    best_mode = 'DC'
    if left_avail and sad_h < sad_dc:
        best_mode = 'H'
        min_sad = sad_h
    else:
        min_sad = sad_dc
    
    if top_avail and sad_v < min_sad:
        best_mode = 'V'
    
    if best_mode == 'DC':
        pred_16x16 = np.full((16, 16), dc16, dtype=np.uint8)
    elif best_mode == 'H':
        pred_16x16 = pred_h
    else:
        pred_16x16 = pred_v
    
    Z_coeffs = []
    for br in range(4):
        for bc in range(4):
            by = br * 4
            bx = bc * 4
            
            block = mb_pixels[by:by+4, bx:bx+4]
            pred_block = pred_16x16[by:by+4, bx:bx+4]
            
            residual = block.astype(np.int16) - pred_block.astype(np.int16)
            W = forward_transform(residual)
            Z = quantize(W, qp)
            
            W_prime = dequantize(Z, qp)
            residual_prime = inverse_transform(W_prime)
            
            recon_raw = pred_block.astype(np.int16) + residual_prime
            recon = clip(recon_raw, 0, 255).astype(np.uint8)
            
            recon_buffer[mb_org_y + by:mb_org_y + by + 4,
                        mb_org_x + bx:mb_org_x + bx + 4] = recon
            
            for i in range(4):
                for j in range(4):
                    Z_coeffs.append(int(Z[i, j]))
    
    return Z_coeffs

def encode_frame(frame_pixels, modes, qp):
    recon_buffer = np.zeros((32, 32), dtype=np.uint8)
    top_line = np.zeros(32, dtype=np.uint8)
    left_line = np.zeros(32, dtype=np.uint8)
    
    all_coeffs = []
    
    mb_positions = [
        (0, 0),
        (16, 0),
        (0, 16),
        (16, 16)
    ]
    
    for mb_idx, (mb_org_x, mb_org_y) in enumerate(mb_positions):
        mb_pixels = frame_pixels[mb_org_y:mb_org_y+16, mb_org_x:mb_org_x+16].copy()
        
        if modes[mb_idx] == 0:
            coeffs = encode_macroblock_intra16x16(mb_pixels, recon_buffer, 
                                                   top_line, left_line,
                                                   mb_org_x, mb_org_y, qp)
        else:
            coeffs = encode_macroblock_intra4x4(mb_pixels, recon_buffer,
                                                top_line, left_line,
                                                mb_org_x, mb_org_y, qp)
        
        all_coeffs.extend(coeffs)
        
        left_line[mb_org_y:mb_org_y+16] = recon_buffer[mb_org_y:mb_org_y+16, mb_org_x + 15]
        top_line[mb_org_x:mb_org_x+16] = recon_buffer[mb_org_y + 15, mb_org_x:mb_org_x+16]
    
    return all_coeffs

# ============================================================================
# 測試數據生成
# ============================================================================

def generate_test_files(seed=42):
    """生成 input.txt 和 golden.txt（全部使用隨機像素）"""
    
    np.random.seed(seed)
    random.seed(seed)
    
    print("="*80)
    print("H.264 Lite Pre-Entropy Encoder - Test File Generator")
    print("="*80)
    print()
    
    # ========================================================================
    # 生成 16 張隨機圖像
    # ========================================================================
    print("🎨 Generating 16 random test frames...")
    frames = []
    for i in range(16):
        # ✅ 所有圖像都使用隨機像素
        frame = np.random.randint(0, 256, (32, 32), dtype=np.uint8)
        frames.append(frame)
        
        # 顯示每張圖的統計信息
        if i % 4 == 0:
            print(f"   Frames {i}-{i+3}: Random pixels (mean: {np.mean(frame):.1f}, std: {np.std(frame):.1f})")
    
    print(f"   ✅ Generated 16 random frames")
    
    # ========================================================================
    # 生成參數（亂序 index）
    # ========================================================================
    print("🎲 Generating parameters...")
    indices = list(range(16))
    random.shuffle(indices)
    
    params = []
    for idx in indices:
        modes = [random.randint(0, 1) for _ in range(4)]
        qp = random.randint(0, 29)
        params.append({
            'index': idx,
            'modes': modes,
            'qp': qp
        })
    
    print(f"   ✅ Generated 16 parameter sets")
    
    # ========================================================================
    # 寫入 input.txt
    # ========================================================================
    print("📝 Writing input.txt...")
    with open('input.txt', 'w') as f:
        f.write("// H.264 Lite Pre-Entropy Encoder - Input File\n")
        f.write("// All 16 frames use random pixels\n\n")
        
        # 像素數據
        f.write("// ===== Pixel Data (16384 values) =====\n")
        for frame_idx, frame in enumerate(frames):
            f.write(f"// Frame {frame_idx} (random)\n")
            for y in range(32):
                line = ' '.join(f"{frame[y, x]:3d}" for x in range(32))
                f.write(f"{line}\n")
        
        f.write("\n")
        
        # 參數
        f.write("// ===== Parameters (16 sets) =====\n")
        f.write("// Format: index qp mode0 mode1 mode2 mode3\n")
        for set_idx, param in enumerate(params):
            f.write(f"{param['index']:2d} {param['qp']:2d}  "
                   f"{param['modes'][0]} {param['modes'][1]} "
                   f"{param['modes'][2]} {param['modes'][3]}"
                   f"  // Set {set_idx}\n")
    
    print(f"   ✅ input.txt written")
    
    # ========================================================================
    # 編碼並生成 golden.txt
    # ========================================================================
    print("🔧 Encoding frames (with reconstruction)...")
    
    golden_outputs = []
    for set_idx, param in enumerate(params):
        frame_idx = param['index']
        frame = frames[frame_idx]
        modes = param['modes']
        qp = param['qp']
        
        if set_idx % 4 == 0:
            print(f"   Encoding sets {set_idx}-{min(set_idx+3, 15)}...")
        
        coeffs = encode_frame(frame, modes, qp)
        
        assert len(coeffs) == 1024, f"Error: Set {set_idx} has {len(coeffs)} coeffs"
        
        golden_outputs.append({
            'set_idx': set_idx,
            'frame_idx': frame_idx,
            'qp': qp,
            'modes': modes,
            'coeffs': coeffs
        })
    
    # 寫入 golden.txt
    with open('golden.txt', 'w') as f:
        f.write("// H.264 Lite Pre-Entropy Encoder - Golden Output\n")
        f.write("// 16 sets × 1024 coefficients = 16384 values\n\n")
        
        for golden in golden_outputs:
            f.write(f"// Set {golden['set_idx']}: "
                   f"Frame {golden['frame_idx']}, "
                   f"QP={golden['qp']}, "
                   f"modes=[{golden['modes'][0]},{golden['modes'][1]},"
                   f"{golden['modes'][2]},{golden['modes'][3]}]\n")
            
            for i in range(0, 1024, 16):
                line = ' '.join(f"{c:6d}" for c in golden['coeffs'][i:i+16])
                f.write(f"{line}\n")
            
            f.write("\n")
    
    print(f"   ✅ golden.txt written")
    
    # ========================================================================
    # 統計信息
    # ========================================================================
    print()
    print("="*80)
    print("📊 Summary")
    print("="*80)
    print(f"Input frames:      16 (all random)")
    print(f"Input pixels:      16384")
    print(f"Parameter sets:    16")
    print(f"Output coeffs:     16384")
    print()
    print("Parameter sequence:")
    for i, param in enumerate(params):
        print(f"  Set {i:2d}: index={param['index']:2d}, "
              f"QP={param['qp']:2d}, modes={param['modes']}")
    print()
    print("="*80)
    print("✅ Files generated successfully!")
    print("   - input.txt   : 16 random frames + parameters")
    print("   - golden.txt  : 16384 golden coefficients")
    print("="*80)
    print()
    print("Next step: Run 'make sim' to test your design")
    print()

# ============================================================================
# 主程序
# ============================================================================

if __name__ == "__main__":
    generate_test_files(seed=42)