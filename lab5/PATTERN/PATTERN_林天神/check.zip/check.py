"""
H.264 4x4 Block Encoder Simulator
用於驗證和除錯 H.264 Intra 預測、轉換、量化流程
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Tuple, List, Optional, Dict
import sys

class H264Encoder:
    """H.264 4x4 塊編碼器模擬器"""
    
    def __init__(self, debug=True):
        """
        初始化編碼器
        
        Parameters:
        -----------
        debug : bool
            是否輸出詳細的除錯信息
        """
        self.debug = debug
        
        # Transform matrix C
        self.C = np.array([
            [ 1,  1,  1,  1],
            [ 1,  1, -1, -1],
            [ 1, -1, -1,  1],
            [ 1, -1,  1, -1]
        ], dtype=np.int32)
        
        # MF table (QP mod 6) - Multiplication Factor for Quantization
        self.MF_table = {
            0: {'a': 13107, 'b': 5243, 'c': 8066},
            1: {'a': 11916, 'b': 4660, 'c': 7490},
            2: {'a': 10082, 'b': 4194, 'c': 6554},
            3: {'a': 9362,  'b': 3647, 'c': 5825},
            4: {'a': 8192,  'b': 3355, 'c': 5243},
            5: {'a': 7282,  'b': 2893, 'c': 4559}
        }
        
        # V table (QP mod 6) - Scaling Factor for Dequantization
        self.V_table = {
            0: {'a': 10, 'b': 16, 'c': 13},
            1: {'a': 11, 'b': 18, 'c': 14},
            2: {'a': 13, 'b': 20, 'c': 16},
            3: {'a': 14, 'b': 23, 'c': 18},
            4: {'a': 16, 'b': 25, 'c': 20},
            5: {'a': 18, 'b': 29, 'c': 23}
        }
        
        # f offset table for quantization
        self.f_table = {
            range(0, 6):   10922,
            range(6, 12):  21845,
            range(12, 18): 43690,
            range(18, 24): 87381,
            range(24, 30): 174762
        }
    
    def print_debug(self, message: str, value=None, indent: int = 0):
        """
        打印調試信息
        
        Parameters:
        -----------
        message : str
            要打印的消息
        value : optional
            要打印的值（可以是數組或標量）
        indent : int
            縮進層級
        """
        if not self.debug:
            return
            
        prefix = "  " * indent
        
        if value is not None:
            if isinstance(value, np.ndarray):
                print(f"\n{prefix}{message}:")
                if value.ndim == 1:
                    print(prefix + " ".join(f"{x:6}" for x in value))
                else:
                    for row in value:
                        print(prefix + " ".join(f"{x:6}" for x in row))
            else:
                print(f"{prefix}{message}: {value}")
        else:
            print(f"\n{prefix}{'='*60}")
            print(f"{prefix}{message}")
            print(f"{prefix}{'='*60}")
    
    def create_MF_matrix(self, qp_mod6: int) -> np.ndarray:
        """
        創建 4x4 MF 矩陣（量化乘法因子）
        
        MF pattern:
        [a c a c]
        [c b c b]
        [a c a c]
        [c b c b]
        """
        params = self.MF_table[qp_mod6]
        a, b, c = params['a'], params['b'], params['c']
        MF = np.array([
            [a, c, a, c],
            [c, b, c, b],
            [a, c, a, c],
            [c, b, c, b]
        ], dtype=np.int32)
        return MF
    
    def create_V_matrix(self, qp_mod6: int) -> np.ndarray:
        """
        創建 4x4 V 矩陣（反量化縮放因子）
        
        V pattern:
        [a c a c]
        [c b c b]
        [a c a c]
        [c b c b]
        """
        params = self.V_table[qp_mod6]
        a, b, c = params['a'], params['b'], params['c']
        V = np.array([
            [a, c, a, c],
            [c, b, c, b],
            [a, c, a, c],
            [c, b, c, b]
        ], dtype=np.int32)
        return V
    
    def get_f_offset(self, QP: int) -> int:
        """獲取量化偏移量 f"""
        for qp_range, offset in self.f_table.items():
            if QP in qp_range:
                return offset
        return 174762  # default for QP >= 24
    
    def intra_predict_dc(self, top: np.ndarray, left: np.ndarray, 
                         top_avail: bool, left_avail: bool, 
                         block_size: int) -> np.ndarray:
        """
        DC 模式預測
        
        公式：
        - 4x4:  dc = (sum(T+L) >> 3) if both available
                     (sum(T) >> 2)   if only T available
                     (sum(L) >> 2)   if only L available
                     128             if none available
        
        - 16x16: 使用 >> 5 和 >> 4
        """
        if block_size == 4:
            shift_both = 3
            shift_one = 2
        else:  # 16x16
            shift_both = 5
            shift_one = 4
        
        if top_avail and left_avail:
            dc = (np.sum(top) + np.sum(left)) >> shift_both
        elif top_avail:
            dc = np.sum(top) >> shift_one
        elif left_avail:
            dc = np.sum(left) >> shift_one
        else:
            dc = 128
        
        pred = np.full((block_size, block_size), dc, dtype=np.uint8)
        return pred
    
    def intra_predict_horizontal(self, left: np.ndarray, block_size: int) -> np.ndarray:
        """
        Horizontal 模式預測
        每一行複製左邊的像素值
        """
        pred = np.repeat(left.reshape(-1, 1), block_size, axis=1)
        return pred.astype(np.uint8)
    
    def intra_predict_vertical(self, top: np.ndarray, block_size: int) -> np.ndarray:
        """
        Vertical 模式預測
        每一列複製上面的像素值
        """
        pred = np.repeat(top.reshape(1, -1), block_size, axis=0)
        return pred.astype(np.uint8)
    
    def calculate_sad(self, block: np.ndarray, pred: np.ndarray) -> int:
        """
        計算 SAD (Sum of Absolute Differences)
        
        SAD = Σ|input(i,j) - predict(i,j)|
        """
        return int(np.sum(np.abs(block.astype(np.int16) - pred.astype(np.int16))))
    
    def select_intra4x4_mode(self, block: np.ndarray, 
                            top: np.ndarray, 
                            left: np.ndarray,
                            top_avail: bool, 
                            left_avail: bool) -> Tuple[np.ndarray, str, Dict]:
        """
        選擇 Intra 4x4 預測模式
        
        規則：
        1. 根據可用性評估相應的模式
        2. 選擇 SAD 最小的模式
        3. 如果 SAD 相同，優先級：DC > H > V
        
        Returns:
        --------
        prediction : np.ndarray
            選擇的預測塊
        mode : str
            選擇的模式名稱
        all_modes : dict
            所有評估的模式及其 SAD
        """
        self.print_debug("=== Intra 4x4 Mode Selection ===", indent=1)
        self.print_debug("Input block", block, indent=1)
        self.print_debug(f"Availability - Top: {top_avail}, Left: {left_avail}", indent=1)
        
        modes = {}
        
        # DC mode (always available)
        pred_dc = self.intra_predict_dc(top, left, top_avail, left_avail, 4)
        sad_dc = self.calculate_sad(block, pred_dc)
        modes['DC'] = {'pred': pred_dc, 'sad': sad_dc}
        self.print_debug(f"DC mode - SAD: {sad_dc}", indent=1)
        
        # Horizontal mode (only if left available)
        if left_avail:
            pred_h = self.intra_predict_horizontal(left, 4)
            sad_h = self.calculate_sad(block, pred_h)
            modes['H'] = {'pred': pred_h, 'sad': sad_h}
            self.print_debug(f"Horizontal mode - SAD: {sad_h}", indent=1)
        
        # Vertical mode (only if top available)
        if top_avail:
            pred_v = self.intra_predict_vertical(top, 4)
            sad_v = self.calculate_sad(block, pred_v)
            modes['V'] = {'pred': pred_v, 'sad': sad_v}
            self.print_debug(f"Vertical mode - SAD: {sad_v}", indent=1)
        
        # Select best mode with priority: DC > H > V
        best_mode = 'DC'
        min_sad = modes['DC']['sad']
        
        if left_avail and modes['H']['sad'] < min_sad:
            best_mode = 'H'
            min_sad = modes['H']['sad']
        
        if top_avail and modes['V']['sad'] < min_sad:
            best_mode = 'V'
        
        self.print_debug(f"Selected mode: {best_mode} (SAD: {min_sad})", indent=1)
        
        return modes[best_mode]['pred'], best_mode, modes
    
    def forward_transform(self, residual: np.ndarray) -> np.ndarray:
        """
        4x4 整數前向轉換
        
        公式: W = C * R * C^T
        
        實現為兩步：
        1. T = C * R  (row transform)
        2. W = T * C^T (column transform)
        """
        self.print_debug("=== Forward Transform ===", indent=1)
        self.print_debug("Residual (R)", residual, indent=1)
        self.print_debug(f"Residual range: [{residual.min()}, {residual.max()}]", indent=1)
        
        # Row transform: T = C * R
        T = self.C @ residual
        self.print_debug("After row transform (T = C * R)", T, indent=1)
        self.print_debug(f"T range: [{T.min()}, {T.max()}]", indent=1)
        
        # Column transform: W = T * C^T
        W = T @ self.C.T
        self.print_debug("After column transform (W = T * C^T)", W, indent=1)
        self.print_debug(f"W range: [{W.min()}, {W.max()}]", indent=1)
        
        return W
    
    def quantize(self, W: np.ndarray, QP: int) -> Tuple[np.ndarray, Dict]:
        """
        量化
        
        公式: Z = sign(W) * ((|W| * MF + f) >> qbits)
        
        其中:
        - qbits = 15 + floor(QP/6)
        - MF 由 QP mod 6 決定
        - f (offset) 由 QP 範圍決定
        """
        self.print_debug("=== Quantization ===", indent=1)
        self.print_debug(f"QP: {QP}", indent=1)
        
        qp_mod6 = QP % 6
        qp_div6 = QP // 6
        qbits = 15 + qp_div6
        f = self.get_f_offset(QP)
        
        self.print_debug(f"qp_mod6: {qp_mod6}, qp_div6: {qp_div6}", indent=1)
        self.print_debug(f"qbits: {qbits}, f (offset): {f}", indent=1)
        
        MF = self.create_MF_matrix(qp_mod6)
        self.print_debug("MF matrix", MF, indent=1)
        
        Z = np.zeros_like(W, dtype=np.int32)
        
        if self.debug:
            print("\n  Quantization process (element-wise):")
        
        for i in range(4):
            for j in range(4):
                w_val = W[i, j]
                sign = np.sign(w_val)
                abs_w = abs(w_val)
                mf_val = MF[i, j]
                
                # 模擬 Verilog 的計算
                mult = abs_w * mf_val
                add_f = mult + f
                mag = add_f >> qbits
                z_val = int(sign * mag)
                
                Z[i, j] = z_val
                
                if self.debug:
                    print(f"    [{i},{j}]: W={w_val:6d}, |W|={abs_w:6d}, "
                          f"MF={mf_val:5d}, mult={mult:10d}, "
                          f"add_f={add_f:10d}, mag={mag:6d}, Z={z_val:6d}")
        
        self.print_debug("Quantized coefficients (Z)", Z, indent=1)
        
        info = {
            'qp_mod6': qp_mod6,
            'qp_div6': qp_div6,
            'qbits': qbits,
            'f': f,
            'MF': MF
        }
        
        return Z, info
    
    def dequantize(self, Z: np.ndarray, QP: int) -> np.ndarray:
        """
        反量化
        
        公式: W' = Z * V * 2^d
        
        其中:
        - d = floor(QP/6)
        - V 由 QP mod 6 決定
        """
        self.print_debug("=== Dequantization ===", indent=1)
        
        qp_mod6 = QP % 6
        qp_div6 = QP // 6
        
        self.print_debug(f"qp_mod6: {qp_mod6}, qp_div6: {qp_div6}", indent=1)
        
        V = self.create_V_matrix(qp_mod6)
        self.print_debug("V matrix", V, indent=1)
        
        # W' = Z * V * 2^qp_div6
        Wp = (Z * V) << qp_div6
        
        self.print_debug("Dequantized coefficients (W')", Wp, indent=1)
        self.print_debug(f"W' range: [{Wp.min()}, {Wp.max()}]", indent=1)
        
        return Wp
    
    def inverse_transform(self, Wp: np.ndarray) -> np.ndarray:
        """
        反向整數轉換
        
        公式: X' = (C^T * W' * C) >> 6
        
        實現為兩步：
        1. Y_col = C^T * W'  (column transform)
        2. Y = Y_col * C      (row transform)
        3. X' = Y >> 6        (scale down)
        """
        self.print_debug("=== Inverse Transform ===", indent=1)
        self.print_debug("Input W'", Wp, indent=1)
        
        # Column transform: Y_col = C^T * W'
        Y_col = self.C.T @ Wp
        self.print_debug("After column transform (Y_col = C^T * W')", Y_col, indent=1)
        self.print_debug(f"Y_col range: [{Y_col.min()}, {Y_col.max()}]", indent=1)
        
        # Row transform: Y = Y_col * C
        Y = Y_col @ self.C
        self.print_debug("After row transform (Y = Y_col * C)", Y, indent=1)
        self.print_debug(f"Y range: [{Y.min()}, {Y.max()}]", indent=1)
        
        # Arithmetic right shift by 6: X' = Y >> 6
        Xp = Y >> 6
        self.print_debug("After shift (X' = Y >> 6)", Xp, indent=1)
        self.print_debug(f"X' range: [{Xp.min()}, {Xp.max()}]", indent=1)
        
        return Xp
    
    def reconstruct(self, Xp: np.ndarray, pred: np.ndarray) -> np.ndarray:
        """
        重建像素值
        
        公式: Rec = clamp(X' + P, 0, 255)
        """
        self.print_debug("=== Reconstruction ===", indent=1)
        self.print_debug("X' (transformed residual)", Xp, indent=1)
        self.print_debug("Prediction (P)", pred, indent=1)
        
        rec = Xp + pred.astype(np.int32)
        self.print_debug("Before clamp (X' + P)", rec, indent=1)
        self.print_debug(f"Range before clamp: [{rec.min()}, {rec.max()}]", indent=1)
        
        rec = np.clip(rec, 0, 255).astype(np.uint8)
        self.print_debug("Reconstructed block (after clamp)", rec, indent=1)
        
        return rec
    
    def encode_4x4_block(self, block: np.ndarray, 
                         top: Optional[np.ndarray] = None, 
                         left: Optional[np.ndarray] = None,
                         QP: int = 20) -> Dict:
        """
        完整的 4x4 塊編碼流程
        
        流程：
        1. Intra Prediction
        2. Residual Calculation
        3. Forward Transform
        4. Quantization
        5. Dequantization
        6. Inverse Transform
        7. Reconstruction
        
        Parameters:
        -----------
        block : np.ndarray (4x4)
            輸入的 4x4 像素塊
        top : np.ndarray (4,) or None
            上方 4 個鄰居像素，None 表示不可用
        left : np.ndarray (4,) or None
            左方 4 個鄰居像素，None 表示不可用
        QP : int
            量化參數 (0-29)
        
        Returns:
        --------
        dict : 包含所有中間結果的字典
        """
        self.print_debug("\n" + "="*80)
        self.print_debug("ENCODING 4x4 BLOCK")
        self.print_debug("="*80)
        
        # 判斷鄰居可用性
        top_avail = (top is not None)
        left_avail = (left is not None)
        
        # 創建默認數組（當不可用時）
        if top is None:
            top = np.zeros(4, dtype=np.uint8)
        if left is None:
            left = np.zeros(4, dtype=np.uint8)
        
        self.print_debug(f"Neighbor availability - Top: {top_avail}, Left: {left_avail}")
        if top_avail:
            self.print_debug("Top pixels", top)
        if left_avail:
            self.print_debug("Left pixels", left)
        
        # 1. Intra Prediction
        pred, mode, modes = self.select_intra4x4_mode(
            block, top, left, top_avail, left_avail
        )
        
        # 2. Residual Calculation
        self.print_debug("\n=== Computing Residual ===")
        residual = block.astype(np.int16) - pred.astype(np.int16)
        self.print_debug("Residual (R = Input - Prediction)", residual, indent=1)
        
        # 3. Forward Transform
        W = self.forward_transform(residual)
        
        # 4. Quantization
        Z, quant_info = self.quantize(W, QP)
        
        # 5. Dequantization
        Wp = self.dequantize(Z, QP)
        
        # 6. Inverse Transform
        Xp = self.inverse_transform(Wp)
        
        # 7. Reconstruction
        rec = self.reconstruct(Xp, pred)
        
        # Calculate errors
        self.print_debug("\n=== Error Analysis ===")
        original_energy = np.sum(residual.astype(np.int32) ** 2)
        reconstruction_residual = rec.astype(np.int16) - block.astype(np.int16)
        reconstruction_error = np.sum(reconstruction_residual.astype(np.int32) ** 2)
        
        self.print_debug(f"Original residual energy (SSE): {original_energy}", indent=1)
        self.print_debug(f"Reconstruction error (SSE): {reconstruction_error}", indent=1)
        self.print_debug("Reconstruction residual", reconstruction_residual, indent=1)
        
        return {
            'input': block,
            'prediction': pred,
            'pred_mode': mode,
            'all_modes': modes,
            'top_avail': top_avail,
            'left_avail': left_avail,
            'residual': residual,
            'W': W,
            'Z': Z,
            'Wp': Wp,
            'Xp': Xp,
            'reconstructed': rec,
            'reconstruction_residual': reconstruction_residual,
            'reconstruction_error': reconstruction_error,
            'original_energy': original_energy,
            'quant_info': quant_info,
            'QP': QP
        }
    
    def visualize_encoding(self, result: Dict, save_path: Optional[str] = None):
        """
        可視化編碼過程
        
        Parameters:
        -----------
        result : dict
            encode_4x4_block 返回的結果字典
        save_path : str or None
            如果指定，將圖像保存到此路徑
        """
        fig, axes = plt.subplots(2, 4, figsize=(16, 8))
        
        qp = result['QP']
        mode = result['pred_mode']
        qbits = result['quant_info']['qbits']
        
        fig.suptitle(f'H.264 4x4 Block Encoding Process\n'
                     f'Mode: {mode} | QP: {qp} | qbits: {qbits}', 
                     fontsize=14, fontweight='bold')
        
        # 1. Original block
        im1 = axes[0, 0].imshow(result['input'], cmap='gray', vmin=0, vmax=255)
        axes[0, 0].set_title('1. Original Block')
        plt.colorbar(im1, ax=axes[0, 0], fraction=0.046)
        
        # 2. Prediction
        im2 = axes[0, 1].imshow(result['prediction'], cmap='gray', vmin=0, vmax=255)
        axes[0, 1].set_title(f'2. Prediction ({mode})')
        plt.colorbar(im2, ax=axes[0, 1], fraction=0.046)
        
        # 3. Residual
        res_max = max(abs(result['residual'].min()), abs(result['residual'].max()))
        if res_max == 0:
            res_max = 1
        im3 = axes[0, 2].imshow(result['residual'], cmap='RdBu_r', 
                                vmin=-res_max, vmax=res_max)
        axes[0, 2].set_title('3. Residual (R)')
        plt.colorbar(im3, ax=axes[0, 2], fraction=0.046)
        
        # 4. Transform coefficients W
        w_max = max(abs(result['W'].min()), abs(result['W'].max()))
        if w_max == 0:
            w_max = 1
        im4 = axes[0, 3].imshow(result['W'], cmap='RdBu_r', 
                                vmin=-w_max, vmax=w_max)
        axes[0, 3].set_title('4. Transform Coef (W)')
        plt.colorbar(im4, ax=axes[0, 3], fraction=0.046)
        
        # 5. Quantized coefficients Z
        z_max = max(abs(result['Z'].min()), abs(result['Z'].max()))
        if z_max == 0:
            z_max = 1
        im5 = axes[1, 0].imshow(result['Z'], cmap='RdBu_r', 
                                vmin=-z_max, vmax=z_max)
        axes[1, 0].set_title('5. Quantized (Z)')
        plt.colorbar(im5, ax=axes[1, 0], fraction=0.046)
        
        # 6. Dequantized W'
        wp_max = max(abs(result['Wp'].min()), abs(result['Wp'].max()))
        if wp_max == 0:
            wp_max = 1
        im6 = axes[1, 1].imshow(result['Wp'], cmap='RdBu_r', 
                                vmin=-wp_max, vmax=wp_max)
        axes[1, 1].set_title("6. Dequantized (W')")
        plt.colorbar(im6, ax=axes[1, 1], fraction=0.046)
        
        # 7. Inverse transform X'
        xp_max = max(abs(result['Xp'].min()), abs(result['Xp'].max()))
        if xp_max == 0:
            xp_max = 1
        im7 = axes[1, 2].imshow(result['Xp'], cmap='RdBu_r', 
                                vmin=-xp_max, vmax=xp_max)
        axes[1, 2].set_title("7. Inv Transform (X')")
        plt.colorbar(im7, ax=axes[1, 2], fraction=0.046)
        
        # 8. Reconstructed
        im8 = axes[1, 3].imshow(result['reconstructed'], cmap='gray', 
                                vmin=0, vmax=255)
        axes[1, 3].set_title('8. Reconstructed')
        plt.colorbar(im8, ax=axes[1, 3], fraction=0.046)
        
        # 移除坐標軸
        for ax in axes.flat:
            ax.set_xticks([])
            ax.set_yticks([])
        
        # 添加誤差信息
        error_text = (f'Original Energy: {result["original_energy"]}\n'
                     f'Reconstruction Error: {result["reconstruction_error"]}')
        fig.text(0.5, 0.02, error_text, ha='center', fontsize=10, 
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        plt.tight_layout(rect=[0, 0.03, 1, 0.96])
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            print(f"\nFigure saved to: {save_path}")
        
        plt.show()
    
    def compare_qp_values(self, block: np.ndarray, 
                         top: Optional[np.ndarray] = None,
                         left: Optional[np.ndarray] = None,
                         qp_list: List[int] = [0, 10, 20, 29]):
        """
        比較不同 QP 值的編碼結果
        
        Parameters:
        -----------
        block : np.ndarray
            輸入塊
        top, left : np.ndarray or None
            鄰居像素
        qp_list : list of int
            要比較的 QP 值列表
        """
        results = []
        
        print("\n" + "="*80)
        print("COMPARING DIFFERENT QP VALUES")
        print("="*80)
        
        for qp in qp_list:
            print(f"\n{'='*60}")
            print(f"Testing with QP = {qp}")
            print('='*60)
            
            result = self.encode_4x4_block(block, top, left, QP=qp)
            results.append(result)
            
            print(f"\nSummary for QP={qp}:")
            print(f"  Selected mode: {result['pred_mode']}")
            print(f"  Max |W|: {np.max(np.abs(result['W']))}")
            print(f"  Max |Z|: {np.max(np.abs(result['Z']))}")
            print(f"  Non-zero Z coeffs: {np.count_nonzero(result    ['Z'])}")
            print(f"  Max |W'|: {np.max(np.abs(result['Wp']))}")
            print(f"  Reconstruction error (SSE): {result['reconstruction_error']}")
        
        # 可視化比較
        fig, axes = plt.subplots(len(qp_list), 4, figsize=(16, 4*len(qp_list)))
        if len(qp_list) == 1:
            axes = axes.reshape(1, -1)
        
        fig.suptitle('Comparison of Different QP Values', fontsize=16, fontweight='bold')
        
        for idx, (qp, result) in enumerate(zip(qp_list, results)):
            # Original (same for all)
            axes[idx, 0].imshow(result['input'], cmap='gray', vmin=0, vmax=255)
            axes[idx, 0].set_title(f'Original\nQP={qp}')
            axes[idx, 0].set_ylabel(f'QP = {qp}', fontsize=12, fontweight='bold')
            
            # Quantized Z
            z_max = max(abs(result['Z'].min()), abs(result['Z'].max()))
            if z_max == 0:
                z_max = 1
            im = axes[idx, 1].imshow(result['Z'], cmap='RdBu_r', 
                                    vmin=-z_max, vmax=z_max)
            axes[idx, 1].set_title(f'Quantized (Z)\nNon-zero: {np.count_nonzero(result["Z"])}')
            plt.colorbar(im, ax=axes[idx, 1], fraction=0.046)
            
            # Reconstructed
            axes[idx, 2].imshow(result['reconstructed'], cmap='gray', vmin=0, vmax=255)
            axes[idx, 2].set_title('Reconstructed')
            
            # Reconstruction error
            err_max = max(abs(result['reconstruction_residual'].min()), 
                         abs(result['reconstruction_residual'].max()))
            if err_max == 0:
                err_max = 1
            im = axes[idx, 3].imshow(result['reconstruction_residual'], 
                                    cmap='RdBu_r', vmin=-err_max, vmax=err_max)
            axes[idx, 3].set_title(f'Recon Error\nSSE: {result["reconstruction_error"]}')
            plt.colorbar(im, ax=axes[idx, 3], fraction=0.046)
        
        # 移除坐標軸
        for ax in axes.flat:
            ax.set_xticks([])
            ax.set_yticks([])
        
        plt.tight_layout()
        plt.show()
        
        return results


# ============================================================================
# 測試函數
# ============================================================================

def test_simple_block():
    """測試 1: 簡單的漸變塊"""
    print("\n" + "="*80)
    print("TEST 1: Simple Gradient Block")
    print("="*80)
    
    encoder = H264Encoder(debug=True)
    
    # 創建一個漸變的 4x4 塊
    block = np.array([
        [219, 57, 12, 140],
        [101, 183, 176, 135],
        [40, 194, 138, 112],
        [202, 81, 216, 32]
    ], dtype=np.uint8)
    
    # 上方和左方的鄰居
    top = np.array([None, None, None, None], dtype=np.uint8)
    left = np.array([None, None, None, None], dtype=np.uint8)
    
    QP = 28
    
    result = encoder.encode_4x4_block(block, top, left, QP=QP)
    encoder.visualize_encoding(result)
    
    return result


def test_flat_block():
    """測試 2: 平坦塊（DC 模式應該最好）"""
    print("\n" + "="*80)
    print("TEST 2: Flat Block (DC mode should win)")
    print("="*80)
    
    encoder = H264Encoder(debug=True)
    
    # 平坦塊
    block = np.full((4, 4), 128, dtype=np.uint8)
    top = np.full(4, 130, dtype=np.uint8)
    left = np.full(4, 126, dtype=np.uint8)
    
    QP = 10
    
    result = encoder.encode_4x4_block(block, top, left, QP=QP)
    encoder.visualize_encoding(result)
    
    return result


def test_vertical_pattern():
    """測試 3: 垂直模式"""
    print("\n" + "="*80)
    print("TEST 3: Vertical Pattern (V mode should win)")
    print("="*80)
    
    encoder = H264Encoder(debug=True)
    
    # 垂直條紋
    block = np.array([
        [100, 150, 100, 150],
        [100, 150, 100, 150],
        [100, 150, 100, 150],
        [100, 150, 100, 150]
    ], dtype=np.uint8)
    
    top = np.array([100, 150, 100, 150], dtype=np.uint8)
    left = np.array([125, 125, 125, 125], dtype=np.uint8)
    
    QP = 15
    
    result = encoder.encode_4x4_block(block, top, left, QP=QP)
    encoder.visualize_encoding(result)
    
    return result


def test_horizontal_pattern():
    """測試 4: 水平模式"""
    print("\n" + "="*80)
    print("TEST 4: Horizontal Pattern (H mode should win)")
    print("="*80)
    
    encoder = H264Encoder(debug=True)
    
    # 水平條紋
    block = np.array([
        [100, 100, 100, 100],
        [150, 150, 150, 150],
        [100, 100, 100, 100],
        [150, 150, 150, 150]
    ], dtype=np.uint8)
    
    top = np.array([125, 125, 125, 125], dtype=np.uint8)
    left = np.array([100, 150, 100, 150], dtype=np.uint8)
    
    QP = 15
    
    result = encoder.encode_4x4_block(block, top, left, QP=QP)
    encoder.visualize_encoding(result)
    
    return result


def test_no_neighbors():
    """測試 5: 沒有鄰居（左上角塊）"""
    print("\n" + "="*80)
    print("TEST 5: No Neighbors Available (Top-Left Corner)")
    print("="*80)
    
    encoder = H264Encoder(debug=True)
    
    # 隨機塊
    np.random.seed(42)
    block = np.random.randint(50, 200, (4, 4), dtype=np.uint8)
    
    QP = 15
    
    # top 和 left 都設為 None
    result = encoder.encode_4x4_block(block, top=None, left=None, QP=QP)
    encoder.visualize_encoding(result)
    
    return result


def test_edge_cases():
    """測試 6: 不同邊界情況"""
    print("\n" + "="*80)
    print("TEST 6: Edge Cases (Different Neighbor Availability)")
    print("="*80)
    
    encoder = H264Encoder(debug=False)  # 關閉詳細輸出
    
    block = np.array([
        [100, 110, 120, 130],
        [105, 115, 125, 135],
        [110, 120, 130, 140],
        [115, 125, 135, 145]
    ], dtype=np.uint8)
    
    top = np.array([95, 105, 115, 125], dtype=np.uint8)
    left = np.array([98, 103, 108, 113], dtype=np.uint8)
    
    test_cases = [
        ("Both available", top, left),
        ("Only top", top, None),
        ("Only left", None, left),
        ("None available", None, None)
    ]
    
    results = []
    
    for name, t, l in test_cases:
        print(f"\n{'='*60}")
        print(f"Case: {name}")
        print('='*60)
        
        result = encoder.encode_4x4_block(block, top=t, left=l, QP=15)
        results.append(result)
        
        print(f"Selected mode: {result['pred_mode']}")
        print(f"Available modes: {list(result['all_modes'].keys())}")
        print(f"Top available: {result['top_avail']}")
        print(f"Left available: {result['left_avail']}")
        print(f"Reconstruction error: {result['reconstruction_error']}")
    
    # 可視化比較
    fig, axes = plt.subplots(4, 3, figsize=(12, 16))
    fig.suptitle('Neighbor Availability Comparison', fontsize=14, fontweight='bold')
    
    for idx, (case_name, result) in enumerate(zip([c[0] for c in test_cases], results)):
        # Original
        axes[idx, 0].imshow(result['input'], cmap='gray', vmin=0, vmax=255)
        axes[idx, 0].set_title(f'{case_name}\nOriginal')
        axes[idx, 0].set_ylabel(case_name, fontsize=10, fontweight='bold')
        
        # Prediction
        axes[idx, 1].imshow(result['prediction'], cmap='gray', vmin=0, vmax=255)
        axes[idx, 1].set_title(f'Prediction\n(Mode: {result["pred_mode"]})')
        
        # Reconstructed
        axes[idx, 2].imshow(result['reconstructed'], cmap='gray', vmin=0, vmax=255)
        axes[idx, 2].set_title(f'Reconstructed\n(Error: {result["reconstruction_error"]})')
    
    for ax in axes.flat:
        ax.set_xticks([])
        ax.set_yticks([])
    
    plt.tight_layout()
    plt.show()
    
    return results


def test_overflow_scenarios():
    """測試 7: 潛在的溢位情況"""
    print("\n" + "="*80)
    print("TEST 7: Overflow Scenarios (Extreme Contrasts)")
    print("="*80)
    
    encoder = H264Encoder(debug=False)  # 關閉詳細輸出避免過多信息
    
    # 極端對比的塊（棋盤格）
    block = np.array([
        [0, 255, 0, 255],
        [255, 0, 255, 0],
        [0, 255, 0, 255],
        [255, 0, 255, 0]
    ], dtype=np.uint8)
    
    # 預測為中間值
    top = np.full(4, 128, dtype=np.uint8)
    left = np.full(4, 128, dtype=np.uint8)
    
    # 測試不同的 QP 值
    encoder.compare_qp_values(block, top, left, qp_list=[0, 10, 20, 29])


def test_qp_comparison():
    """測試 8: QP 值比較"""
    print("\n" + "="*80)
    print("TEST 8: QP Value Comparison")
    print("="*80)
    
    encoder = H264Encoder(debug=False)
    
    # 使用一個有細節的塊
    block = np.array([
        [100, 120, 140, 160],
        [110, 130, 150, 170],
        [90, 110, 130, 150],
        [80, 100, 120, 140]
    ], dtype=np.uint8)
    
    top = np.array([95, 115, 135, 155], dtype=np.uint8)
    left = np.array([95, 105, 85, 75], dtype=np.uint8)
    
    encoder.compare_qp_values(block, top, left, qp_list=[0, 5, 10, 15, 20, 25])


def test_custom_block():
    """測試 9: 自定義塊"""
    print("\n" + "="*80)
    print("TEST 9: Custom Block (Interactive)")
    print("="*80)
    
    encoder = H264Encoder(debug=True)
    
    # 你可以在這裡修改成你想測試的塊
    block = np.array([
        [120, 125, 130, 135],
        [122, 127, 132, 137],
        [124, 129, 134, 139],
        [126, 131, 136, 141]
    ], dtype=np.uint8)
    
    top = np.array([118, 123, 128, 133], dtype=np.uint8)
    left = np.array([119, 121, 123, 125], dtype=np.uint8)
    
    QP = 18
    
    result = encoder.encode_4x4_block(block, top, left, QP=QP)
    encoder.visualize_encoding(result)
    
    return result


def run_all_tests():
    """執行所有測試"""
    print("\n" + "="*80)
    print("H.264 4x4 BLOCK ENCODER SIMULATOR")
    print("Running All Tests")
    print("="*80)
    
    tests = [
        ("Simple Gradient Block", test_simple_block),
        ("Flat Block", test_flat_block),
        ("Vertical Pattern", test_vertical_pattern),
        ("Horizontal Pattern", test_horizontal_pattern),
        ("No Neighbors", test_no_neighbors),
        ("Edge Cases", test_edge_cases),
        ("Overflow Scenarios", test_overflow_scenarios),
        ("QP Comparison", test_qp_comparison),
    ]
    
    results = {}
    
    for test_name, test_func in tests:
        try:
            print(f"\n{'='*80}")
            print(f"Running: {test_name}")
            print('='*80)
            result = test_func()
            results[test_name] = result
            print(f"✓ {test_name} completed successfully")
        except Exception as e:
            print(f"✗ {test_name} failed with error: {e}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "="*80)
    print("ALL TESTS COMPLETED!")
    print("="*80)
    
    return results


def interactive_mode():
    """互動模式：讓用戶輸入參數"""
    print("\n" + "="*80)
    print("H.264 ENCODER SIMULATOR - INTERACTIVE MODE")
    print("="*80)
    
    encoder = H264Encoder(debug=True)
    
    # 輸入塊
    print("\nEnter 4x4 block values (comma-separated, row by row):")
    print("Example: 100,110,120,130")
    
    block = []
    for i in range(4):
        row_input = input(f"Row {i}: ")
        row = [int(x.strip()) for x in row_input.split(',')]
        if len(row) != 4:
            print("Error: Need exactly 4 values per row")
            return
        block.append(row)
    
    block = np.array(block, dtype=np.uint8)
    
    # 輸入 top 鄰居
    top_input = input("\nTop neighbors (4 values, or 'none'): ")
    if top_input.lower() == 'none':
        top = None
    else:
        top = np.array([int(x.strip()) for x in top_input.split(',')], dtype=np.uint8)
    
    # 輸入 left 鄰居
    left_input = input("Left neighbors (4 values, or 'none'): ")
    if left_input.lower() == 'none':
        left = None
    else:
        left = np.array([int(x.strip()) for x in left_input.split(',')], dtype=np.uint8)
    
    # 輸入 QP
    qp = int(input("QP value (0-29): "))
    
    # 編碼
    result = encoder.encode_4x4_block(block, top, left, QP=qp)
    encoder.visualize_encoding(result)
    
    return result


# ============================================================================
# 主程序
# ============================================================================

def print_menu():
    """打印選單"""
    print("\n" + "="*80)
    print("H.264 4x4 BLOCK ENCODER SIMULATOR")
    print("="*80)
    print("\nAvailable Tests:")
    print("  1. Simple Gradient Block")
    print("  2. Flat Block (DC mode)")
    print("  3. Vertical Pattern")
    print("  4. Horizontal Pattern")
    print("  5. No Neighbors (corner block)")
    print("  6. Edge Cases (all availability scenarios)")
    print("  7. Overflow Scenarios")
    print("  8. QP Comparison")
    print("  9. Custom Block")
    print("  0. Run All Tests")
    print("  i. Interactive Mode")
    print("  q. Quit")
    print("="*80)


def main():
    """主函數"""
    while True:
        print_menu()
        choice = input("\nSelect a test (1-9, 0, i, or q): ").strip().lower()
        
        if choice == 'q':
            print("\nExiting simulator. Goodbye!")
            break
        elif choice == '1':
            test_simple_block()
        elif choice == '2':
            test_flat_block()
        elif choice == '3':
            test_vertical_pattern()
        elif choice == '4':
            test_horizontal_pattern()
        elif choice == '5':
            test_no_neighbors()
        elif choice == '6':
            test_edge_cases()
        elif choice == '7':
            test_overflow_scenarios()
        elif choice == '8':
            test_qp_comparison()
        elif choice == '9':
            test_custom_block()
        elif choice == '0':
            run_all_tests()
        elif choice == 'i':
            interactive_mode()
        else:
            print("\nInvalid choice. Please try again.")
        
        input("\nPress Enter to continue...")


if __name__ == "__main__":
    # 可以直接運行特定測試，或者運行互動模式
    
    # 方式 1: 運行互動式選單
    main()
    
    # 方式 2: 直接運行單個測試（註釋掉 main() 並取消註釋下面的代碼）
    # test_simple_block()
    
    # 方式 3: 運行所有測試
    # run_all_tests()
    
    # 方式 4: 互動模式
    # interactive_mode()