# -*- coding: utf-8 -*-
"""
H.2C4 Lite Prediction and Transform Engine (HLPTE) - Final Corrected Version with Debug Output

This version handles both Intra 4x4 and Intra 16x16 macroblock modes and
prints the detailed debug trace for ALL processed 4x4 blocks.
"""
import numpy as np

# ==============================================================================
#  常數與查找表
# ==============================================================================

# -- 整數轉換矩陣 (最終正確版本) --
C_f = np.array([
    [ 1,  1,  1,  1],
    [ 1,  1, -1, -1],
    [ 1, -1, -1,  1],
    [ 1, -1,  1, -1]
], dtype=np.int32)
C_i = C_f

# -- 量化表 --
MF_TABLE = {
    0: [13107, 5243, 8066], 1: [11916, 4660, 7490], 2: [10082, 4194, 6554],
    3: [9362, 3647, 5825],  4: [8192, 3355, 5243], 5: [7282, 2893, 4559]
}
F_TABLE = [(0, 5, 10922), (6, 11, 21845), (12, 17, 43690),
           (18, 23, 87381), (24, 29, 174762)]

# -- 反量化表 --
V_TABLE = {
    0: [10, 16, 13], 1: [11, 18, 14], 2: [13, 20, 16],
    3: [14, 23, 18], 4: [16, 25, 20], 5: [18, 29, 23]
}

# ==============================================================================
#  預測階段函數
# ==============================================================================
def calculate_sad(original, predicted):
    return np.sum(np.abs(original.astype(np.int32) - predicted.astype(np.int32)))

def predict_dc_4x4(T, L):
    """
    DC 預測函數 (已修正為 floor/truncation)
    """
    pred = np.zeros((4, 4), dtype=np.int32)
    T_available, L_available = T is not None, L is not None
    if T_available and L_available:
        dc = (np.sum(T) + np.sum(L)) // 8
    elif T_available:
        dc = np.sum(T) // 4
    elif L_available:
        dc = np.sum(L) // 4
    else:
        dc = 128
    pred.fill(dc)
    return pred

def predict_horizontal_4x4(L):
    pred = np.zeros((4, 4), dtype=np.int32)
    if L is not None:
        for i in range(4): pred[i, :] = L[i]
    return pred

def predict_vertical_4x4(T):
    pred = np.zeros((4, 4), dtype=np.int32)
    if T is not None:
        for j in range(4): pred[:, j] = T[j]
    return pred

def predict_dc_16x16(T, L):
    """
    16x16 DC 預測函數 (已修正為 floor/truncation)
    """
    pred = np.zeros((16, 16), dtype=np.int32)
    T_available, L_available = T is not None, L is not None
    if T_available and L_available:
        dc = (np.sum(T) + np.sum(L)) // 32
    elif T_available:
        dc = np.sum(T) // 16
    elif L_available:
        dc = np.sum(L) // 16
    else:
        dc = 128
    pred.fill(dc)
    return pred

def predict_horizontal_16x16(L):
    pred = np.zeros((16, 16), dtype=np.int32)
    if L is not None:
        for i in range(16): pred[i, :] = L[i]
    return pred

def predict_vertical_16x16(T):
    pred = np.zeros((16, 16), dtype=np.int32)
    if T is not None:
        for j in range(16): pred[:, j] = T[j]
    return pred


def find_best_mode_4x4(original_block, T, L):
    sads = {}
    predictions = {}
    T_available, L_available = T is not None, L is not None

    predictions[0] = predict_dc_4x4(T, L)
    sads[0] = calculate_sad(original_block, predictions[0])
    
    if L_available:
        predictions[1] = predict_horizontal_4x4(L)
        sads[1] = calculate_sad(original_block, predictions[1])
    
    if T_available:
        predictions[2] = predict_vertical_4x4(T)
        sads[2] = calculate_sad(original_block, predictions[2])

    min_sad_val = min(sads.values())
    
    # 根據優先序 DC > H > V 找出最佳模式
    if sads.get(0) == min_sad_val:
        best_mode = 0
    elif sads.get(1) == min_sad_val:
        best_mode = 1
    elif sads.get(2) == min_sad_val:
        best_mode = 2
    else: # 備用，理論上不會發生
        best_mode = 0

    return best_mode, predictions[best_mode]

def find_best_mode_16x16(original_mb, T, L):
    sads = {}
    predictions = {}
    T_available, L_available = T is not None, L is not None

    predictions[0] = predict_dc_16x16(T, L)
    sads[0] = calculate_sad(original_mb, predictions[0])
    
    if L_available:
        predictions[1] = predict_horizontal_16x16(L)
        sads[1] = calculate_sad(original_mb, predictions[1])
    
    if T_available:
        predictions[2] = predict_vertical_16x16(T)
        sads[2] = calculate_sad(original_mb, predictions[2])
    
    min_sad_val = min(sads.values())

    if sads.get(0) == min_sad_val:
        best_mode = 0
    elif sads.get(1) == min_sad_val:
        best_mode = 1
    elif sads.get(2) == min_sad_val:
        best_mode = 2
    else:
        best_mode = 0
        
    return best_mode, predictions[best_mode]


# ==============================================================================
#  轉換階段函數
# ==============================================================================

def integer_transform_4x4(block_x):
    return C_f @ block_x @ C_f.T

def quantize_4x4(block_w, qp):
    qbits = 15 + (qp // 6)
    a, b, c = MF_TABLE[qp % 6]
    mf = np.array([[a, c, a, c], [c, b, c, b], [a, c, a, c], [c, b, c, b]], dtype=np.int64)
    f = next(val for low, high, val in F_TABLE if low <= qp <= high)
    
    sign_w = np.sign(block_w)
    abs_w = np.abs(block_w)
    
    mult_result = abs_w * mf
    add_result = mult_result + f
    block_z_abs = add_result >> qbits

    return (block_z_abs * sign_w).astype(np.int32)

def dequantize_4x4(block_z, qp):
    a, b, c = V_TABLE[qp % 6]
    v = np.array([[a, c, a, c], [c, b, c, b], [a, c, a, c], [c, b, c, b]], dtype=np.int32)
    scale_factor = 1 << (qp // 6)
    return block_z * v * scale_factor

# ==============================================================================
#  主 HLPTE 編碼器函數
# ==============================================================================

def hlpte_encoder(original_frame, mb_modes, qp):
    frame_size = original_frame.shape[0]
    mb_size = 16
    block_size = 4

    pre_entropy_frame_Z = np.zeros_like(original_frame, dtype=np.int32)
    reconstructed_frame_R = np.zeros_like(original_frame, dtype=np.int32)
    residual_frame_X = np.zeros_like(original_frame, dtype=np.int32)

    mb_idx = 0
    for mb_r in range(0, frame_size, mb_size):
        for mb_c in range(0, frame_size, mb_size):
            mode_16x16_or_4x4 = mb_modes[mb_idx]
            original_mb = original_frame[mb_r:mb_r+mb_size, mb_c:mb_c+mb_size]

            # 步驟 1: 如果是 16x16 模式，先計算整個宏區塊的預測
            predicted_mb_P = None
            best_mode_16x16 = None
            if mode_16x16_or_4x4 == 0:
                T = reconstructed_frame_R[mb_r-1, mb_c:mb_c+mb_size] if mb_r > 0 else None
                L = reconstructed_frame_R[mb_r:mb_r+mb_size, mb_c-1] if mb_c > 0 else None
                best_mode_16x16, predicted_mb_P = find_best_mode_16x16(original_mb, T, L)

            # 步驟 2: 遍歷宏區塊內部所有的 4x4 區塊
            for r_off in range(0, mb_size, block_size):
                for c_off in range(0, mb_size, block_size):
                    r, c = mb_r + r_off, mb_c + c_off
                    block_I = original_frame[r:r+block_size, c:c+block_size]

                    # 步驟 3: 確定當前 4x4 區塊的預測塊 P
                    best_mode_4x4 = None
                    if mode_16x16_or_4x4 == 1: # 如果是 4x4 模式，獨立計算預測
                        T = reconstructed_frame_R[r-1, c:c+block_size] if r > 0 else None
                        L = reconstructed_frame_R[r:r+block_size, c-1] if c > 0 else None
                        best_mode_4x4, block_P = find_best_mode_4x4(block_I, T, L)
                    else: # 如果是 16x16 模式，直接取對應部分
                        block_P = predicted_mb_P[r_off:r_off+block_size, c_off:c_off+block_size]

                    # 步驟 4: 執行轉換、量化、重建的循環 (對所有 4x4 區塊都一樣)
                    block_X = block_I.astype(np.int32) - block_P
                    residual_frame_X[r:r+block_size, c:c+block_size] = block_X
                    
                    block_W = integer_transform_4x4(block_X)
                    block_Z = quantize_4x4(block_W, qp)
                    pre_entropy_frame_Z[r:r+block_size, c:c+block_size] = block_Z

                    block_W_prime = dequantize_4x4(block_Z, qp)
                    
                    y = C_i.T @ block_W_prime @ C_i
                    block_X_prime = y >> 6
                    
                    block_R = block_X_prime + block_P
                    
                    # --- 除錯打印區塊 (現在對所有區塊生效) ---
                    mode_map = {0: "DC", 1: "Horizontal", 2: "Vertical"}
                    current_mode_num = best_mode_16x16 if mode_16x16_or_4x4 == 0 else best_mode_4x4
                    mode_prefix = "MB " if mode_16x16_or_4x4 == 0 else ""

                    print(f"\n--- [除錯] 詳細步驟 for Block ({r//4}, {c//4}) ---")
                    print(f"Chosen Prediction Mode: {mode_prefix}{current_mode_num} ({mode_map.get(current_mode_num, 'Unknown')})")
                    print("Predicted Block (P):\n", block_P)
                    print("Residual (X):\n", block_X)
                    print("W (輸入轉換後矩陣):\n", block_W)
                    print("Quantized Block (Z):\n", block_Z)
                    print("Dequantized Block (W'):\n", block_W_prime)
                    print("Inverse Transform (Y = Ci.T * W' * Ci):\n", y)
                    print("Inverse Transform Result (X' = Y >> 6):\n", block_X_prime)
                    print("Reconstruction (R = X' + P):\n", block_R)
                    print("Final Clipped Reconstruction Block:\n", np.clip(block_R, 0, 255))
                    print("-------------------------------------------------------\n")
                    # --- 除錯結束 ---
                    
                    reconstructed_frame_R[r:r+block_size, c:c+block_size] = np.clip(block_R, 0, 255)

            mb_idx += 1

    return pre_entropy_frame_Z, reconstructed_frame_R.astype(np.uint8), residual_frame_X

# ==============================================================================
#  執行與結果顯示
# ==============================================================================
if __name__ == '__main__':
    input_image_list = [
        [15, 253, 174, 246, 221, 233, 160, 134, 122, 48, 232, 176, 117, 207, 247, 93, 111, 192, 184, 24, 169, 69, 181, 197, 121, 214, 137, 154, 228, 176, 60, 115],
        [69, 83, 177, 207, 216, 34, 27, 74, 209, 173, 193, 47, 90, 48, 19, 120, 83, 24, 226, 123, 47, 13, 13, 129, 218, 235, 23, 250, 243, 170, 109, 248],
        [220, 102, 67, 212, 77, 54, 246, 214, 66, 19, 218, 9, 30, 153, 171, 141, 238, 50, 136, 201, 61, 33, 229, 91, 70, 40, 194, 65, 143, 33, 27, 183],
        [12, 206, 245, 98, 85, 222, 242, 107, 197, 143, 197, 204, 5, 153, 168, 83, 109, 36, 242, 153, 228, 92, 35, 128, 82, 233, 182, 112, 31, 25, 1, 167],
        [242, 68, 154, 245, 185, 70, 159, 138, 143, 46, 147, 23, 49, 2, 186, 27, 245, 147, 173, 11, 165, 154, 14, 201, 207, 168, 2, 73, 226, 8, 132, 113],
        [31, 216, 28, 196, 85, 1, 250, 187, 248, 7, 12, 214, 145, 3, 236, 25, 12, 119, 183, 81, 86, 252, 249, 188, 226, 140, 1, 194, 113, 138, 146, 44],
        [247, 111, 135, 96, 26, 200, 242, 14, 196, 224, 228, 250, 230, 228, 231, 117, 58, 118, 108, 194, 180, 158, 248, 44, 22, 49, 154, 97, 202, 161, 110, 150],
        [70, 45, 109, 172, 248, 75, 249, 45, 253, 136, 23, 126, 79, 242, 228, 25, 126, 51, 201, 119, 27, 194, 96, 112, 4, 154, 203, 173, 195, 0, 87, 200],
        [173, 241, 231, 229, 172, 192, 179, 232, 77, 22, 187, 151, 136, 196, 143, 32, 224, 188, 241, 168, 215, 11, 202, 116, 20, 255, 23, 243, 251, 229, 243, 39],
        [131, 41, 45, 197, 234, 147, 98, 119, 17, 153, 20, 97, 99, 81, 24, 142, 69, 148, 233, 137, 46, 28, 82, 65, 66, 229, 237, 35, 129, 163, 254, 85],
        [82, 177, 112, 219, 1, 225, 235, 209, 149, 29, 62, 230, 115, 143, 19, 140, 137, 231, 95, 216, 17, 250, 37, 69, 68, 138, 47, 215, 52, 225, 206, 32],
        [105, 32, 75, 76, 39, 177, 151, 12, 165, 67, 139, 151, 2, 122, 167, 178, 46, 10, 246, 149, 140, 61, 154, 10, 253, 247, 249, 187, 148, 103, 169, 79],
        [101, 11, 232, 36, 217, 168, 245, 91, 120, 196, 221, 80, 36, 40, 182, 165, 123, 215, 74, 75, 198, 118, 75, 126, 176, 251, 20, 111, 53, 212, 233, 129],
        [100, 74, 198, 20, 133, 251, 78, 93, 204, 147, 127, 214, 141, 73, 96, 41, 175, 178, 208, 77, 188, 246, 217, 230, 141, 184, 15, 76, 24, 34, 17, 224],
        [56, 191, 119, 95, 251, 70, 79, 134, 234, 184, 153, 167, 38, 89, 242, 144, 122, 121, 202, 203, 79, 247, 180, 13, 194, 122, 197, 1, 69, 52, 94, 68],
        [160, 59, 63, 52, 218, 224, 255, 114, 125, 64, 174, 204, 173, 213, 148, 40, 82, 121, 29, 207, 15, 77, 114, 221, 172, 15, 114, 160, 45, 74, 30, 72],
        [50, 174, 163, 202, 36, 40, 175, 35, 160, 84, 63, 229, 75, 131, 133, 55, 53, 31, 4, 170, 57, 205, 112, 163, 109, 222, 59, 239, 211, 170, 185, 79],
        [209, 35, 131, 78, 122, 77, 65, 137, 3, 58, 12, 151, 83, 119, 11, 198, 191, 78, 49, 220, 133, 212, 133, 125, 163, 108, 204, 6, 239, 218, 8, 139],
        [198, 49, 37, 34, 140, 42, 65, 212, 133, 8, 43, 1, 232, 7, 228, 197, 45, 212, 192, 128, 119, 225, 142, 43, 244, 39, 169, 31, 203, 160, 249, 88],
        [241, 44, 73, 194, 14, 39, 36, 131, 217, 37, 250, 227, 253, 185, 11, 84, 31, 137, 158, 179, 8, 108, 82, 67, 188, 84, 123, 198, 73, 13, 243, 229],
        [101, 49, 20, 50, 60, 224, 250, 2, 99, 33, 249, 10, 54, 70, 147, 110, 148, 200, 24, 211, 143, 152, 172, 12, 90, 164, 23, 125, 152, 90, 228, 151],
        [208, 46, 94, 146, 128, 254, 58, 190, 132, 45, 131, 21, 21, 103, 106, 250, 199, 211, 162, 216, 89, 253, 173, 216, 22, 178, 173, 72, 87, 10, 128, 219],
        [90, 178, 133, 178, 218, 35, 43, 84, 73, 197, 38, 213, 62, 104, 83, 123, 124, 40, 223, 183, 57, 11, 8, 11, 242, 244, 23, 25, 207, 43, 231, 134],
        [222, 14, 17, 145, 104, 226, 93, 114, 173, 145, 255, 130, 249, 242, 173, 203, 15, 128, 91, 58, 68, 140, 7, 36, 245, 174, 240, 152, 81, 202, 123, 137],
        [9, 65, 23, 134, 182, 67, 254, 205, 116, 80, 223, 43, 171, 192, 158, 138, 26, 211, 209, 197, 77, 173, 118, 220, 169, 214, 174, 55, 33, 89, 238, 172],
        [158, 245, 51, 174, 194, 77, 146, 214, 189, 25, 105, 118, 15, 161, 37, 102, 145, 201, 119, 43, 80, 32, 199, 250, 236, 47, 37, 194, 165, 200, 92, 155],
        [90, 248, 76, 6, 158, 159, 23, 30, 195, 123, 37, 234, 110, 75, 213, 253, 15, 124, 247, 59, 59, 81, 99, 237, 6, 15, 144, 118, 238, 145, 21, 248],
        [100, 225, 201, 245, 24, 134, 144, 170, 228, 122, 195, 118, 238, 81, 10, 113, 25, 175, 120, 36, 50, 161, 38, 81, 10, 70, 72, 218, 160, 206, 255, 100],
        [92, 4, 34, 162, 224, 5, 83, 3, 206, 174, 165, 191, 195, 230, 118, 180, 163, 213, 72, 154, 123, 170, 107, 139, 158, 113, 70, 60, 250, 45, 147, 61],
        [46, 249, 7, 237, 7, 52, 141, 63, 148, 212, 3, 239, 94, 92, 51, 161, 98, 33, 233, 161, 163, 171, 143, 223, 192, 21, 104, 114, 158, 139, 88, 191],
        [30, 157, 240, 100, 129, 211, 105, 38, 112, 243, 222, 35, 163, 25, 175, 54, 51, 222, 179, 227, 232, 91, 1, 50, 149, 205, 195, 5, 136, 31, 115, 213],
        [207, 121, 202, 87, 69, 155, 57, 140, 17, 175, 145, 185, 10, 124, 52, 112, 116, 231, 119, 28, 11, 103, 221, 15, 26, 107, 11, 62, 157, 102, 216, 146],
    ]
    original_frame = np.array(input_image_list, dtype=np.uint8)
    mb_modes = [1, 0, 0, 0] 
    QP = 16

    # --- 執行完整的 HLPTE 編碼器 ---
    final_Z, final_R, final_X = hlpte_encoder(original_frame, mb_modes, QP)

    # --- 顯示最終結果 ---
    print("\n\n" + "="*25 + " FINAL RESULTS " + "="*25)
    print(f"輸入 QP: {QP}\n")

    # 配置 numpy 以打印完整的矩陣而不換行
    np.set_printoptions(linewidth=200, threshold=np.inf, suppress=True)

    print(">> 最終輸出: Residual Frame (X)")
    print(final_X)
    print("\n" + "="*60 + "\n")

    print(">> 最終輸出: Pre-Entropy Frame (Z)")
    print(final_Z)
    print("\n" + "="*60 + "\n")

    print(">> 最終輸出: Reconstructed Frame (R)")
    print(final_R)

